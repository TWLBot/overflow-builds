#include <gba_input.h>

int main(int argc, char **argv) {
	
while (1) {
scanKeys();
	int pressed = keysHeld();

	if (pressed & KEY_A) {
			drawtext(0,"You Pressed A!",0);
	} else if (pressed & KEY_B) {
			drawtext(0,"You Pressed B!",0);
	} else if (pressed & KEY_L) {
			drawtext(0,"You Pressed L!",0);
	} else if (pressed & KEY_R) {
			drawtext(0,"You Pressed R!",0);
	} else if (pressed & KEY_RIGHT) {
			drawtext(0,"You Pressed Right!",0);
	} else if (pressed & KEY_LEFT) {
			drawtext(0,"You Pressed Left!",0);
	} else if (pressed & KEY_DOWN) {
			drawtext(0,"You Pressed Down!",0);
	} else if (pressed & KEY_UP) {
			drawtext(0,"You Pressed Up!",0);
	} else if (pressed & KEY_START) {
			drawtext(0,"You Pressed Start!",0);
	} else if (pressed & KEY_SELECT) {
			drawtext(0,"You Pressed Select!",0);
	} else {
			break;
			}
	}
	return 0;
}
