# Button-Tester
My first GBA Homebrew, hense being so simple
